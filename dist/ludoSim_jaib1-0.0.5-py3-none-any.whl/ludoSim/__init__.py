name = "ludoSim"

from ludoSim.Board import Board
from ludoSim.Player import Player
from ludoSim.Piece import Piece
