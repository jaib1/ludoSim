# To run tests for the ludoSim package, navigate to ludoSim's parent directory 
# and run the following in python:
import pytest
pytest.main(['ludoSim/tests/test_ludo.py'])